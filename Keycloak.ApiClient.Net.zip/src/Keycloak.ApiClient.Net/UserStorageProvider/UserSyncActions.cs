﻿namespace Keycloak.ApiClient.Net
{
    public enum UserSyncActions
    {
        Full,
        Changed
    }
}