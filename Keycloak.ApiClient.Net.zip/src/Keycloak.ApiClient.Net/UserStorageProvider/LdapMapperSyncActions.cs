﻿namespace Keycloak.ApiClient.Net
{
    public enum LdapMapperSyncActions
    {
        FedToKeycloak,
        KeycloakToFed
    }
}