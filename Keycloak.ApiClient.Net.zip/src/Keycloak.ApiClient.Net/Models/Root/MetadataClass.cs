﻿namespace Keycloak.ApiClient.Net.Models.Root
{
    public class MetadataClass
    {
    }
}