﻿namespace Keycloak.ApiClient.Net.Models.RealmsAdmin
{
    public enum Policies
    {
        Skip,
        Overwrite,
        Fail
    }
}
